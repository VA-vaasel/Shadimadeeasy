UPDATE `settings` SET `value` = '4.6' WHERE `settings`.`type` = 'current_version';

COMMIT;