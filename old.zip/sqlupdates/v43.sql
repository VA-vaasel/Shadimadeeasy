UPDATE `settings` SET `value` = '4.3' WHERE `settings`.`type` = 'current_version';

COMMIT;