UPDATE `settings` SET `value` = '3.7' WHERE `settings`.`type` = 'current_version';

COMMIT;


