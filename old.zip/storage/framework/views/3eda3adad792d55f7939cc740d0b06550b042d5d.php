<div class="chat-box-wrap h-100">
    <div class="attached-top bg-white border-bottom chat-header d-flex justify-content-between align-items-center p-3 shadow-sm">
        <div class="media align-items-center">
            <span class="avatar avatar-sm mr-3 flex-shrink-0">
              <?php
                  $current_user = Auth::user()->id;
              ?>
                <?php if($current_user == $chat_thread->sender->id): ?>
                  <?php $user_to_show = 'receiver';  ?>
                <?php else: ?>
                  <?php $user_to_show = 'sender';  ?>
                <?php endif; ?>

                <?php if($chat_thread->$user_to_show->photo != null): ?>
                    <img src="<?php echo e(uploaded_asset($chat_thread->$user_to_show->photo)); ?>">
                <?php else: ?>
                    <img src="<?php echo e(static_asset('assets/frontend/default/img/avatar-place.png')); ?>">
                <?php endif; ?>
            </span>
            <div class="media-body">
                <h6 class="fs-15 mb-1">
                    <?php echo e($chat_thread->$user_to_show->first_name.' '.$chat_thread->$user_to_show->last_name); ?>

                    <?php if(Cache::has('user-is-online-' . $chat_thread->$user_to_show->id)): ?>
                        <span class="badge badge-dot badge-success badge-circle"></span>
                    <?php else: ?>
                        <span class="badge badge-dot badge-secondary badge-circle"></span>
                    <?php endif; ?>
                </h6>
            </div>
        </div>
        <div class="d-flex align-items-center">
            <button class="aiz-mobile-toggler d-lg-none aiz-all-chat-toggler mr-2" data-toggle="class-toggle" data-target=".chat-user-list-wrap">
                <span></span>
            </button>
            <button class="btn btn-icon btn-circle btn-soft-primary chat-info" data-toggle="class-toggle" data-target=".chat-info-wrap"><i class="las la-info-circle"></i></button>
        </div>
    </div>
    <div class="chat-list-wrap c-scrollbar-light scroll-to-btm" id="parentDiv">
        <?php if(count($chats) > 0): ?>
            <div class="chat-coversation-load text-center">
                <button class="btn btn-link load-more-btn" data-first="<?php echo e($chats->last()->id); ?>" type="button"><?php echo e(translate('Load More')); ?></button>
            </div>
        <?php endif; ?>
        <div class="chat-list px-4" id="chat-messages">
            <?php echo $__env->make('frontend.member.messages.messages_part',['chats' => $chats], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="chat-footer border-top p-3 attached-bottom bg-white">
        <form id="send-mesaage">
            <div class="input-group">
                <input type="hidden" id="chat_thread_id" name="chat_thread_id" value="<?php echo e($chat_thread->id); ?>">
                <input type="text" class="form-control" name="message" id="message" placeholder="Your Message.." autocomplete="off">
                <input type="hidden" class="" name="attachment" id="attachment">
                <div class="input-group-append">
                    <button class="btn btn-circle btn-icon chat-attachment" type="button">
                        <i class="las la-paperclip"></i>
                    </button>
                    <button class="btn btn-primary btn-circle btn-icon" onclick="send_reply()" type="button">
                        <i class="las la-paper-plane"></i>
                    </button>
                </div>
            </div>
        </form>
    </div>
    <div class="chat-info-wrap">
        <div class="overlay dark c-pointer" data-toggle="class-toggle" data-target=".chat-info-wrap" data-same=".chat-info"></div>
          <div class="chat-info c-scrollbar-light p-4 z-1">
                <div class="px-4 text-center mb-3">
                    <span class="avatar avatar-md mb-3">
                        <?php if($chat_thread->$user_to_show->photo != null): ?>
                            <img src="<?php echo e(uploaded_asset($chat_thread->$user_to_show->photo)); ?>">
                        <?php else: ?>
                            <img src="<?php echo e(static_asset('assets/frontend/default/img/avatar-place.png')); ?>">
                        <?php endif; ?>
                    </span>
                    <h4 class="h5 mb-2 fw-600"><?php echo e($chat_thread->$user_to_show->first_name.' '.$chat_thread->$user_to_show->last_name); ?></h4>
                </div>
                <div class="text-center">
                    <h6 class="fs-13"><?php echo e(translate('Age')); ?>: <?php echo e(\Carbon\Carbon::parse($chat_thread->$user_to_show->member->birthday)->age); ?></h6>
                    <h6 class="fs-13">
                        <?php echo e(translate('Height')); ?> :
                        <?php if(!empty( $chat_thread->$user_to_show->physical_attributes->height)): ?>
                            <?php echo e($chat_thread->$user_to_show->physical_attributes->height); ?>

                        <?php endif; ?>
                    </h6>
                    <?php if(get_setting('member_spiritual_and_social_background_section') == 'on'): ?>
                        <h6 class="fs-13">
                            <?php echo e(translate('Religion')); ?> :
                          <?php if(!empty($chat_thread->$user_to_show->spiritual_backgrounds->religion_id)): ?>
                              <?php echo e($chat_thread->$user_to_show->spiritual_backgrounds->religion->name); ?>

                          <?php endif; ?>
                        </h6>
                    <?php endif; ?>
                    <?php if(get_setting('member_present_address_section') == 'on'): ?>
                    <h6 class="fs-13">
                        <?php echo e(translate('Location')); ?> :
                      <?php
                          $present_address = \App\Models\Address::where('type','present')->where('user_id', $chat_thread->$user_to_show->id)->first();
                      ?>
                      <?php if(!empty($present_address->country_id)): ?>
                          <?php echo e($present_address->country->name); ?>

                      <?php endif; ?>
                    </h6>
                    <?php endif; ?>
                    <?php if(get_setting('member_language_section') == 'on'): ?>
                        <h6 class="fs-13">
                            <?php echo e(translate('Mother Tongue')); ?> :
                          <?php if($chat_thread->$user_to_show->member->mothere_tongue != null): ?>
                              <?php echo e(\App\Models\MemberLanguage::where('id',$chat_thread->$user_to_show->member->mothere_tongue)->first()->name); ?>

                          <?php endif; ?>
                        </h6>
                    <?php endif; ?>

                    <div class="text-center mb-3 px-3 mt-3">
                        <a
                            <?php if(get_setting('full_profile_show_according_to_membership') == 1 && Auth::user()->membership == 1): ?>
                                href="javascript:void(0);" onclick="package_update_alert()"
                            <?php else: ?>
                                href="<?php echo e(route('member_profile', $chat_thread->$user_to_show->id)); ?>"
                            <?php endif; ?>
                            class="btn btn-block btn-soft-primary"><?php echo e(translate('View Full Profile')); ?>

                        </a>
                    </div>
                </div>
            </div>
    </div>
</div>
<?php /**PATH /home/poly1278/shadi.polytronx.com/resources/views/frontend/member/messages/messages.blade.php ENDPATH**/ ?>