<?php echo $email_body; ?>

<?php /**PATH /home/poly1278/shadi.polytronx.com/resources/views/emails/index.blade.php ENDPATH**/ ?>