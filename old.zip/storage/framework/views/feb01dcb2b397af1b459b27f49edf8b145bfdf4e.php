
<?php $__env->startSection('content'); ?>
    <section class="py-5 bg-white">
        <div class="container">
            <div class="row">

                <div class="col-lg-10 mx-auto">
                    <form action="<?php echo e(route('wallet.recharge')); ?>" class="form-default" role="form" method="POST"
                        id="package-payment-form">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" id="payment_type" value="">

                        <div class="card shadow-none">
                            <div class="card-header p-3">
                                <h3 class="fs-16 fw-600 mb-0">
                                    <?php echo e(translate('Select a payment option')); ?>

                                </h3>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-xxl-10 col-xl-10 mx-auto">
                                        <div class="form-group row">
                                            <label class="col-md-2 col-form-label"><?php echo e(translate('Amount')); ?><span
                                                    class="text-danger"> *</span></label>
                                            <div class="col-md-10">
                                                <input type="text" name="amount" id="amount" class="form-control"
                                                    placeholder="<?php echo e(translate('Amount')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="row gutters-10">
                                            <?php if(get_setting('paypal_payment_activation') == 1): ?>
                                                <div class="col-4 col-md-2">
                                                    <label class="aiz-megabox d-block mb-3">
                                                        <input value="paypal" class="online_payment" type="radio"
                                                            name="payment_option">
                                                        <span class="d-block p-3 aiz-megabox-elem">
                                                            <img src="<?php echo e(static_asset('assets/img/payment_method/paypal.png')); ?>"
                                                                class="img-fluid mb-2">
                                                            <span class="d-block text-center">
                                                                <span
                                                                    class="d-block fw-600 fs-15"><?php echo e(translate('Paypal')); ?></span>
                                                            </span>
                                                        </span>
                                                    </label>
                                                </div>
                                            <?php endif; ?>
                                            <?php if(get_setting('stripe_payment_activation') == 1): ?>
                                                <div class="col-4 col-md-2">
                                                    <label class="aiz-megabox d-block mb-3">
                                                        <input value="stripe" class="online_payment" type="radio"
                                                            name="payment_option">
                                                        <span class="d-block p-3 aiz-megabox-elem">
                                                            <img src="<?php echo e(static_asset('assets/img/payment_method/stripe.png')); ?>"
                                                                class="img-fluid mb-2">
                                                            <span class="d-block text-center">
                                                                <span
                                                                    class="d-block fw-600 fs-15"><?php echo e(translate('Stripe')); ?></span>
                                                            </span>
                                                        </span>
                                                    </label>
                                                </div>
                                            <?php endif; ?>
                                            <?php if(get_setting('instamojo_payment_activation') == 1): ?>
                                                <div class="col-4 col-md-2">
                                                    <label class="aiz-megabox d-block mb-3">
                                                        <input value="instamojo" class="online_payment" type="radio"
                                                            name="payment_option">
                                                        <span class="d-block p-3 aiz-megabox-elem">
                                                            <img src="<?php echo e(static_asset('assets/img/payment_method/instamojo.png')); ?>"
                                                                class="img-fluid mb-2">
                                                            <span class="d-block text-center">
                                                                <span
                                                                    class="d-block fw-600 fs-15"><?php echo e(translate('Instamojo')); ?></span>
                                                            </span>
                                                        </span>
                                                    </label>
                                                </div>
                                            <?php endif; ?>
                                            <?php if(get_setting('razorpay_payment_activation') == 1): ?>
                                                <div class="col-4 col-md-2">
                                                    <label class="aiz-megabox d-block mb-3">
                                                        <input value="razorpay" class="online_payment" type="radio"
                                                            name="payment_option">
                                                        <span class="d-block p-3 aiz-megabox-elem">
                                                            <img src="<?php echo e(static_asset('assets/img/payment_method/rozarpay.png')); ?>"
                                                                class="img-fluid mb-2">
                                                            <span class="d-block text-center">
                                                                <span
                                                                    class="d-block fw-600 fs-15"><?php echo e(translate('Razorpay')); ?></span>
                                                            </span>
                                                        </span>
                                                    </label>
                                                </div>
                                            <?php endif; ?>
                                            <?php if(get_setting('paystack_payment_activation') == 1): ?>
                                                <div class="col-4 col-md-2">
                                                    <label class="aiz-megabox d-block mb-3">
                                                        <input value="paystack" class="online_payment" type="radio"
                                                            name="payment_option">
                                                        <span class="d-block p-3 aiz-megabox-elem">
                                                            <img src="<?php echo e(static_asset('assets/img/payment_method/paystack.png')); ?>"
                                                                class="img-fluid mb-2">
                                                            <span class="d-block text-center">
                                                                <span
                                                                    class="d-block fw-600 fs-15"><?php echo e(translate('Paystack')); ?></span>
                                                            </span>
                                                        </span>
                                                    </label>
                                                </div>
                                            <?php endif; ?>
                                            <?php if(get_setting('paytm_payment_activation') == 1): ?>
                                                <div class="col-4 col-md-2">
                                                    <label class="aiz-megabox d-block mb-3">
                                                        <input value="paytm" class="online_payment" type="radio"
                                                            name="payment_option">
                                                        <span class="d-block p-3 aiz-megabox-elem">
                                                            <img src="<?php echo e(static_asset('assets/img/payment_method/paytm.png')); ?>"
                                                                class="img-fluid mb-2">
                                                            <span class="d-block text-center">
                                                                <span
                                                                    class="d-block fw-600 fs-15"><?php echo e(translate('Paytm')); ?></span>
                                                            </span>
                                                        </span>
                                                    </label>
                                                </div>
                                            <?php endif; ?>
                                            <?php if(get_setting('aamarpay_payment_activation') == 1): ?>
                                                <div class="col-4 col-md-2">
                                                    <label class="aiz-megabox d-block mb-3">
                                                        <input value="aamarpay" class="online_payment" type="radio"
                                                            name="payment_option">
                                                        <span class="d-block p-3 aiz-megabox-elem">
                                                            <img src="<?php echo e(static_asset('assets/img/payment_method/aamarpay.png')); ?>"
                                                                class="img-fluid mb-2">
                                                            <span class="d-block text-center">
                                                                <span
                                                                    class="d-block fw-600 fs-15"><?php echo e(translate('Aamarpay')); ?></span>
                                                            </span>
                                                        </span>
                                                    </label>
                                                </div>
                                            <?php endif; ?>
                                            <?php if(get_setting('sslcommerz_payment_activation') == 1): ?>
                                                <div class="col-4 col-md-2">
                                                    <label class="aiz-megabox d-block mb-3">
                                                        <input value="sslcommerz" class="online_payment" type="radio"
                                                            name="payment_option">
                                                        <span class="d-block p-3 aiz-megabox-elem">
                                                            <img src="<?php echo e(static_asset('assets/img/payment_method/sslcommerz.png')); ?>"
                                                                class="img-fluid mb-2">
                                                            <span class="d-block text-center">
                                                                <span
                                                                    class="d-block fw-600 fs-15"><?php echo e(translate('Sslcommerz')); ?></span>
                                                            </span>
                                                        </span>
                                                    </label>
                                                </div>
                                            <?php endif; ?>

                                            <?php $__currentLoopData = $manual_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-4 col-md-2">
                                                    <label class="aiz-megabox d-block mb-3">
                                                        <input type="hidden" name="manual_payment_id"
                                                            value="<?php echo e($method->id); ?>">
                                                        <input value="manual_payment" class="manual_payment"
                                                            id="payment_option" type="radio"
                                                            data-method-id="<?php echo e($method->id); ?>" name="payment_option"
                                                            onchange="toggleManualPaymentData(<?php echo e($method->id); ?>)">
                                                        <span class="d-block p-3 aiz-megabox-elem">
                                                            <img src="<?php echo e(uploaded_asset($method->photo)); ?>"
                                                                class="img-fluid mb-2">
                                                            <span class="d-block text-center">
                                                                <span
                                                                    class="d-block fw-600 fs-15"><?php echo e($method->heading); ?></span>
                                                            </span>
                                                        </span>
                                                    </label>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>

                                    <?php $__currentLoopData = $manual_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div id="manual_payment_info_<?php echo e($method->id); ?>" class="d-none col-6 col-md-4">

                                            <div><?php echo $method->description ?></div>
                                            <?php if($method->bank_info != null): ?>
                                                <ul>
                                                    <?php $__currentLoopData = json_decode($method->bank_info); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li style="list-style: none ">
                                                            <?php echo e(translate('Bank Name')); ?> -<?php echo e($info->bank_name); ?>

                                                        </li>
                                                        <li style="list-style: none ">
                                                            <?php echo e(translate('Account Name')); ?> - <?php echo e($info->account_name); ?>,
                                                        </li>
                                                        <li style="list-style: none ">
                                                            <?php echo e(translate('Account Number')); ?> -<?php echo e($info->account_number); ?>

                                                        </li>
                                                        <li style="list-style: none ">
                                                            <?php echo e(translate('Routing Number')); ?> -
                                                            <?php echo e($info->routing_number); ?>

                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card mb-3 p-3 d-none w-100 manual_payment_description">
                                        <div id="manual_payment_description">

                                        </div>
                                    </div>

                                    <div class="col-md-10 mx-auto d-none" id="purchase_by_manual_payment">
                                        <div class="form-group row">
                                            <div class="col-md-6">
                                                <label><?php echo e(translate('Transaction Id')); ?><span class="text-danger">
                                                        *</span></label>
                                                <input type="text" name="transaction_id" id="transaction_id"
                                                    class="form-control" placeholder="<?php echo e(translate('Transaction Id')); ?>">
                                            </div>
                                            <div class="col-md-6">
                                                <label><?php echo e(translate('Payment Proof')); ?><span class="text-danger">
                                                        *</span></label>
                                                <div class="input-group" data-toggle="aizuploader" data-type="image">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text bg-soft-secondary font-weight-medium">
                                                            <?php echo e(translate('Browse')); ?></div>
                                                    </div>
                                                    <div class="form-control file-amount"><?php echo e(translate('Choose File')); ?>

                                                    </div>
                                                    <input type="hidden" name="payment_proof" id="payment_proof"
                                                        class="selected-files">
                                                </div>
                                                <div class="file-preview box sm">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <label><?php echo e(translate('Payment Details')); ?></label>
                                                <textarea type="text" name="payment_details" class="form-control" rows="2"
                                                    placeholder="<?php echo e(translate('Payment Details')); ?>"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class=" text-right pt-3">
                            <button type="button" onclick="package_purchase(this)"
                                class="btn btn-primary fw-600 purchase_button"
                                disabled><?php echo e(translate('Confirm')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        function package_purchase(el) {
            $(el).prop('disabled', true);

            var amount = $("#amount").val();
            if (amount != '') {
                var payment_type = $("#payment_type").val();
                if (payment_type == 'manual_payment' && amount != '') {
                    var transaction_id = $("#transaction_id").val();
                    var payment_proof = $("#payment_proof").val();
                    if (transaction_id == '' || payment_proof == '') {
                        AIZ.plugins.notify('danger',
                            '<?php echo e(translate('Please Provide transaction id and payemnt proof.')); ?>');
                        $(el).prop('disabled', false);
                    } else {
                        $('#package-payment-form').submit();
                    }
                } else {
                    $('#package-payment-form').submit();
                }
            } else {
                AIZ.plugins.notify('danger', '<?php echo e(translate('Please add wallet recharge amount first.')); ?>');
                $(el).prop('disabled', false);
            }
        }

        // 

        $(".online_payment").click(function() {
            $('.manual_payment_description').addClass('d-none');
            $('#purchase_by_manual_payment').addClass('d-none');
            $(".purchase_button").prop('disabled', false);
            $("#payment_type").val('online_payment');
        });
        $(".manual_payment").click(function() {
            $('.manual_payment_description').removeClass('d-none');
            $(".purchase_button").prop('disabled', false);
        });

        function toggleManualPaymentData(id) {
            $('#manual_payment_description').parent().removeClass('d-none');
            $('#manual_payment_description').html($('#manual_payment_info_' + id).html());
            $('#purchase_by_manual_payment').removeClass('d-none');
            $('.manual_payment_id').val(id)

        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/poly1278/shadi.polytronx.com/resources/views/frontend/member/wallet/recharge_methods.blade.php ENDPATH**/ ?>