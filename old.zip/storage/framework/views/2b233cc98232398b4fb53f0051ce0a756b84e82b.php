
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0 h6"><?php echo e(translate('Offline Wallet Recharge Requests')); ?></h5>
    </div>
    <div class="card-body">
        <table class="table aiz-table mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th><?php echo e(translate('Name')); ?></th>
                    <th><?php echo e(translate('Amount')); ?></th>
                    <th><?php echo e(translate('Method')); ?></th>
                    <th><?php echo e(translate('Approval')); ?></th>
                    <th><?php echo e(translate('Date')); ?></th>
                    <th class="text-right"><?php echo e(translate('Options')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><?php echo e(($key+1)); ?></td>
                      <td>
                        <?php if($wallet->user != null): ?>
                          <?php echo e($wallet->user->first_name.' '.$wallet->user->last_name); ?>

                        <?php endif; ?>
                      </td>
                      <td><?php echo e(single_price($wallet->amount)); ?></td>
                      <td><?php echo e(ucwords(str_replace("_"," ",$wallet->payment_method))); ?></td>
                      <td>
                        <?php if($wallet->approval == 1): ?>
                            <span class="badge badge-inline badge-success text-center"><?php echo e(translate('Approved')); ?></span>
                        <?php else: ?>
                            <span class="badge badge-inline badge-info text-center"><?php echo e(translate('Pending')); ?></span>
                        <?php endif; ?>
                      </td>
                      <td><?php echo e($wallet->created_at); ?></td>
                      <td class="text-right">
                        <a href="javascript:void(0);" onclick="wallet_payment_details('<?php echo e(route('wallet_payment_details', $wallet->id )); ?>')" class="btn btn-soft-info btn-icon btn-circle btn-sm" title="<?php echo e(translate('View Details')); ?>">
                            <i class="las la-eye"></i>
                        </a>
                      </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="aiz-pagination">
            <?php echo e($wallets->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <?php echo $__env->make('modals.create_edit_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  function wallet_payment_details(url){
      $.get(url, function(data){
          $('.create_edit_modal_content').html(data);
          $('.create_edit_modal').modal('show');
      });
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/poly1278/shadi.polytronx.com/resources/views/admin/wallet/manual_recharge_requests.blade.php ENDPATH**/ ?>