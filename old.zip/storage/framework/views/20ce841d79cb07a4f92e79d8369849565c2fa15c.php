<div class="modal-header">
    <h5 class="modal-title h6"><?php echo e(translate('Wallet Payment Details')); ?></h5>
    <button type="button" class="close" data-dismiss="modal"></button>
</div>
<div class="modal-body">
    <table class="table table-bordered">
        <tbody>
            <tr>
                <th><?php echo e(translate('Payment Method')); ?></th>
                <td><?php echo e(ucwords(str_replace('_', ' ', $wallet_payment->payment_method))); ?></td>
            </tr>
            <tr>
                <th><?php echo e(translate('Transaction Id')); ?></th>
                <td><?php echo e($wallet_payment->transaction_id); ?></td>
            </tr>
            <tr>
                <th><?php echo e(translate('Payemnt Proof')); ?></th>
                <td>
                    <a href="<?php echo e(uploaded_asset($wallet_payment->reciept)); ?>" target="_blank" download="">
                        <span><?php echo e($wallet_payment->reciept ? translate('Download') : 'No receipt found'); ?></span>
                    </a>
                </td>
            </tr>
            <tr>
                <th><?php echo e(translate('Details')); ?></th>
                <td><?php echo e($wallet_payment->payment_details); ?></td>
            </tr>
        </tbody>
    </table>
</div>
<div class="modal-footer">
    <?php if($wallet_payment->approval != 1): ?>
        <a href="<?php echo e(route('wallet_manual_payment_accept', $wallet_payment->id)); ?>"
            class="btn btn-sm btn-success"><?php echo e(translate('Accept')); ?></a>
    <?php endif; ?>
    <button type="button" class="btn btn-sm btn-light" data-dismiss="modal"><?php echo e(translate('Close')); ?></button>
</div>
<?php /**PATH /home/poly1278/shadi.polytronx.com/resources/views/admin/wallet/wallet_payment_details.blade.php ENDPATH**/ ?>