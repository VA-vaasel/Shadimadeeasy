
<?php $__env->startSection('content'); ?>

<div class="aiz-titlebar mt-2 mb-4">
    <div class="row align-items-center">
        <div class="col-md-6">
            <h1 class="h3"><?php echo e(translate('Unapproved Profile Pictures')); ?></h1>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
      <h5 class="mb-md-0 h6"><?php echo e(translate('Profile Pictures')); ?></h5>
    </div>
    <div class="card-body">
        <table class="table aiz-table mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th><?php echo e(translate('Photo')); ?></th>
                    <th><?php echo e(translate('Member Code')); ?></th>
                    <th><?php echo e(translate('Member Name')); ?></th>
                    <th><?php echo e(translate('Approval')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key + 1 + ($users->currentPage() - 1) * $users->perPage()); ?></td>
                        <td>
                            <?php if(uploaded_asset($user->photo) != null): ?>
                                <img class="img-md" src="<?php echo e(uploaded_asset($user->photo)); ?>" height="45px"  alt="<?php echo e(translate('photo')); ?>">
                            <?php else: ?>
                                <img class="img-md" src="<?php echo e(static_asset('assets/img/avatar-place.png')); ?>" height="45px"  alt="<?php echo e(translate('photo')); ?>">
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($user->code); ?></td>
                        <td><?php echo e($user->first_name.' '.$user->last_name); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('approve_profile_picrures')): ?>
                            <label class="aiz-switch aiz-switch-success mb-0">
                                <input type="checkbox" id="status.<?php echo e($key); ?>"
                                   onchange="approve_profile_image(this)" value="<?php echo e($user->id); ?>" data-switch="success"/ >
                                <span></span>
                            </label>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="aiz-pagination">
            <?php echo e($users->appends(request()->input())->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function approve_profile_image(el) {
            $.post('<?php echo e(route('approve_profile_image')); ?>', {
                _token: '<?php echo e(csrf_token()); ?>',
                id: el.value
            }, function (data) {
                if (data == 1) {
                    location.reload();
                } else {
                    AIZ.plugins.notify('danger', 'Something went wrong');
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/poly1278/shadi.polytronx.com/resources/views/admin/members/unapproved_member_profile_pictures.blade.php ENDPATH**/ ?>