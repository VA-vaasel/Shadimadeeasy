
<?php $__env->startSection('panel_content'); ?>
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0 h6"><?php echo e(translate('Interest Requests')); ?></h5>
        </div>
        <div class="card-body">
            <table class="table aiz-table mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo e(translate('Image')); ?></th>
                        <th><?php echo e(translate('Name')); ?></th>
                        <th><?php echo e(translate('Age')); ?></th>
                        <th class="text-center"><?php echo e(translate('Action')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $interests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $interest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $interested_by = \App\Models\User::where('id',$interest->interested_by)->first(); ?>
                        <?php if($interested_by != null): ?>
                            <tr id="interested_member_<?php echo e($interested_by->id); ?>">
                                <td><?php echo e($key + 1 + ($interests->currentPage() - 1) * $interests->perPage()); ?></td>
                                <td>
                                    <a <?php if(get_setting('full_profile_show_according_to_membership') == 1 && Auth::user()->membership == 1): ?> href="javascript:void(0);" onclick="package_update_alert()"
                                        <?php else: ?>
                                            href="<?php echo e(route('member_profile', $interested_by->id)); ?>" <?php endif; ?>
                                        class="text-reset c-pointer">
                                        <?php if(uploaded_asset($interested_by->photo) != null): ?>
                                            <img class="img-md" src="<?php echo e(uploaded_asset($interested_by->photo)); ?>"
                                                height="45px" alt="<?php echo e(translate('photo')); ?>">
                                        <?php else: ?>
                                            <img class="img-md" src="<?php echo e(static_asset('assets/img/avatar-place.png')); ?>"
                                                height="45px" alt="<?php echo e(translate('photo')); ?>">
                                        <?php endif; ?>
                                    </a>
                                </td>
                                <td>
                                    <a <?php if(get_setting('full_profile_show_according_to_membership') == 1 && Auth::user()->membership == 1): ?> href="javascript:void(0);" onclick="package_update_alert()"
                                        <?php else: ?>
                                            href="<?php echo e(route('member_profile', $interested_by->id)); ?>" <?php endif; ?>
                                        class="text-reset c-pointer">
                                        <?php echo e($interested_by->first_name . ' ' . $interested_by->last_name); ?>

                                </td>
                                </a>

                                <td><?php echo e(\Carbon\Carbon::parse($interested_by->member->birthday)->age); ?></td>
                                <td class="text-center">
                                    <?php if($interest->status != 1): ?>
                                        <a href="javascript:void(0);" onclick="accept_interest(<?php echo e($interest->id); ?>)"
                                            class="btn btn-soft-success btn-icon btn-circle btn-sm"
                                            title="<?php echo e(translate('Accept')); ?>">
                                            <i class="las la-check"></i>
                                        </a>
                                        <a href="javascript:void(0);" onclick="reject_interest(<?php echo e($interest->id); ?>)"
                                            class="btn btn-soft-danger btn-icon btn-circle btn-sm confirm-delete"
                                            title="<?php echo e(translate('Reject')); ?>">
                                            <i class="las la-trash"></i>
                                        </a>
                                    <?php else: ?>
                                        <span class="badge badge-inline badge-success"><?php echo e(translate('Accepted')); ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="aiz-pagination">
                <?php echo e($interests->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
    
    <div class="modal fade interest_accept_modal">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title h6"><?php echo e(translate('Interest Accept!')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                </div>
                <div class="modal-body text-center">
                    <form class="form-horizontal member-block" action="<?php echo e(route('accept_interest')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="interest_id" id="interest_accept_id" value="">
                        <p class="mt-1"><?php echo e(translate('Are you sure you want to accept this interest?')); ?></p>
                        <button type="button" class="action-btn btn btn-danger mt-2"
                            data-dismiss="modal"><?php echo e(translate('Cancel')); ?></button>
                        <button type="submit" class="action-btn btn btn-info mt-2"><?php echo e(translate('Confirm')); ?></a>
                    </form>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade interest_reject_modal">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title h6"><?php echo e(translate('Interest Reject !')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                </div>
                <div class="modal-body text-center">
                    <form class="form-horizontal member-block" action="<?php echo e(route('reject_interest')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="interest_id" id="interest_reject_id" value="">
                        <p class="mt-1"><?php echo e(translate('Are you sure you want to rejet his interest?')); ?></p>
                        <button type="button" class="btn btn-danger mt-2"
                            data-dismiss="modal"><?php echo e(translate('Cancel')); ?></button>
                        <button type="submit" class="btn btn-info mt-2 action-btn"><?php echo e(translate('Confirm')); ?></a>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        function accept_interest(id) {
            $('.interest_accept_modal').modal('show');
            $('#interest_accept_id').val(id);
        }

        function reject_interest(id) {
            $('.interest_reject_modal').modal('show');
            $('#interest_reject_id').val(id);
        }
        // Prevent submitting multiple button
        $('form').bind('submit', function(e) {
            if ($(".action-btn").attr('attempted') == 'true') {
                //stop submitting the form and disable the submit button.
                e.preventDefault();
                $(".action-btn").attr("disable", true);
            } else {
                $(".action-btn").attr("attempted", 'true');
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.member_panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/poly1278/shadi.polytronx.com/resources/views/frontend/member/interest_requests.blade.php ENDPATH**/ ?>