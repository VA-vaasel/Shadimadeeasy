

<?php $__env->startSection('content'); ?>
<div class="py-4 py-lg-5">
	<div class="container">
		<div class="row">
			<div class="col-xxl-6 col-xl-6 col-md-8 mx-auto">
				<div class="card">
					<div class="card-body">

						<div class="mb-5 text-center">
							<h1 class="h3 text-primary mb-0"><?php echo e(translate('Create Your Account')); ?></h1>
							<p><?php echo e(translate('Fill out the form to get started')); ?>.</p>
						</div>
						<form class="form-default" id="reg-form" role="form" action="<?php echo e(route('register')); ?>" method="POST">
							<?php echo csrf_field(); ?>
							<div class="row">
								<div class="col-lg-12">
									<div class="form-group mb-3">
										<label class="form-label" for="on_behalf"><?php echo e(translate('On Behalf')); ?></label>
										<?php $on_behalves = \App\Models\OnBehalf::all(); ?>
										<select class="form-control aiz-selectpicker <?php $__errorArgs = ['on_behalf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="on_behalf" required>
											<?php $__currentLoopData = $on_behalves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $on_behalf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($on_behalf->id); ?>"><?php echo e($on_behalf->name); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
										<?php $__errorArgs = ['on_behalf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
							</div>
							<div class="row">
						        <div class="col-lg-6">
						            <div class="form-group mb-3">
										<label class="form-label" for="name"><?php echo e(translate('First Name')); ?></label>
										<input type="text" class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="first_name" id="first_name" placeholder="<?php echo e(translate('First Name')); ?>"  required>
										<?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						            </div>
						        </div>
								<div class="col-lg-6">
									<div class="form-group mb-3">
										<label class="form-label" for="name"><?php echo e(translate('Last Name')); ?></label>
										<input type="text" class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="last_name" id="last_name" placeholder="<?php echo e(translate('Last Name')); ?>"  required>
										<?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
    						</div>
							<div class="row">
								<div class="col-lg-6">
									<div class="form-group mb-3">
										<label class="form-label" for="gender"><?php echo e(translate('Gender')); ?></label>
										<select class="form-control aiz-selectpicker <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gender" required>
											<option value="1"><?php echo e(translate('Male')); ?></option>
											<option value="2"><?php echo e(translate('Female')); ?></option>
										</select>
										<?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group mb-3">
										<label class="form-label" for="name"><?php echo e(translate('Date Of Birth')); ?></label>
										<input type="text" class="form-control aiz-date-range <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="date_of_birth" id="date_of_birth" placeholder="<?php echo e(translate('Date Of Birth')); ?>" data-single="true" data-show-dropdown="true" data-max-date="<?php echo e(get_max_date()); ?>" autocomplete="off" required>
										<?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
							</div>
							<?php if(addon_activation('otp_system')): ?>
								<div>
									<div class="d-flex justify-content-between align-items-start">
										<label class="form-label" for="email"><?php echo e(translate('Email / Phone')); ?></label>
										<button class="btn btn-link p-0 opacity-50 text-reset fs-12" type="button" onclick="toggleEmailPhone(this)"><?php echo e(translate('Use Email Instead')); ?></button>
									</div>
									<div class="form-group phone-form-group mb-1">
							            <input type="number" id="phone-code" class="form-control<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('phone')); ?>" placeholder="" name="phone" autocomplete="off">
							        </div>

							        <input type="hidden" name="country_code" value="">

							        <div class="form-group email-form-group mb-1 d-none">
							            <input type="email" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(translate('Email')); ?>" name="email"  autocomplete="off">
							            <?php if($errors->has('email')): ?>
							                <span class="invalid-feedback" role="alert">
							                    <strong><?php echo e($errors->first('email')); ?></strong>
							                </span>
							            <?php endif; ?>
							        </div>
							    </div>
							<?php else: ?>
								<div class="row">
									<div class="col-lg-12">
									  <div class="form-group mb-3">
											<label class="form-label" for="email"><?php echo e(translate('Email address')); ?></label>
											<input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" id="signinSrEmail" placeholder="<?php echo e(translate('Email Address')); ?>" >
									        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									            <span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
									        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									  </div>
									</div>
								</div>
							<?php endif; ?>
							<div class="row">
								<div class="col-lg-6">
									<div class="form-group mb-3">
										<label class="form-label" for="password"><?php echo e(translate('Password')); ?></label>
										<input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="********" aria-label="********" required>
										<small><?php echo e(translate('Minimun 8 characters')); ?></small>
										<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group mb-3">
										<label class="form-label" for="password-confirm"><?php echo e(translate('Confirm password')); ?></label>
										<input type="password" class="form-control" name="password_confirmation" placeholder="********" required>
										<small><?php echo e(translate('Minimun 8 characters')); ?></small>
									</div>
								</div>
							</div>

							<?php if(addon_activation('referral_system')): ?>
							<div class="row">
								<div class="col-lg-12">
									<div class="form-group mb-3">
										<label class="form-label" for="email"><?php echo e(translate('Referral Code')); ?></label>
										<input type="text" class="form-control<?php echo e($errors->has('referral_code') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('referral_code')); ?>" placeholder="<?php echo e(translate('Referral Code')); ?>" name="referral_code">
										<?php if($errors->has('referral_code')): ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($errors->first('referral_code')); ?></strong>
											</span>
										<?php endif; ?>
									</div>
								</div>
							</div>
							<?php endif; ?>

							<?php if(get_setting('google_recaptcha_activation') == 1): ?>
							<div class="form-group">
								<div class="g-recaptcha" data-sitekey="<?php echo e(env('CAPTCHA_KEY')); ?>"></div>
								<?php $__errorArgs = ['g-recaptcha-response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
							<?php endif; ?>

							<div class="mb-3">
								<label class="aiz-checkbox">
								<input type="checkbox" name="checkbox_example_1" required>
									<span class=opacity-60><?php echo e(translate('By signing up you agree to our')); ?>

										<a href="<?php echo e(env('APP_URL').'/terms-conditions'); ?>" target="_blank"><?php echo e(translate('terms and conditions')); ?>.</a>
									</span>
									<span class="aiz-square-check"></span>
								</label>
							</div>
							<?php $__errorArgs = ['checkbox_example_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

							<div class="mb-5">
								<button type="submit" class="btn btn-block btn-primary"><?php echo e(translate('Create Account')); ?></button>
							</div>
							<?php if(get_setting('google_login_activation') == 1 || get_setting('facebook_login_activation') == 1 || get_setting('twitter_login_activation') == 1 || get_setting('apple_login_activation') == 1): ?>
			                <div class="mb-5">
			                    <div class="separator mb-3">
			                        <span class="bg-white px-3"><?php echo e(translate('Or Join With')); ?></span>
			                    </div>
	                    		<ul class="list-inline social colored text-center">
									<?php if(get_setting('facebook_login_activation') == 1): ?>
			                        <li class="list-inline-item">
			                            <a href="<?php echo e(route('social.login', ['provider' => 'facebook'])); ?>" class="facebook" title="<?php echo e(translate('Facebook')); ?>"><i class="lab la-facebook-f"></i></a>
			                        </li>
									<?php endif; ?>
									<?php if(get_setting('google_login_activation') == 1): ?>
									<li class="list-inline-item">
										<a href="<?php echo e(route('social.login', ['provider' => 'google'])); ?>" class="google" title="<?php echo e(translate('Google')); ?>"><i class="lab la-google"></i></a>
									</li>
									<?php endif; ?>
									<?php if(get_setting('twitter_login_activation') == 1): ?>
			                        <li class="list-inline-item">
			                            <a href="<?php echo e(route('social.login', ['provider' => 'twitter'])); ?>" class="twitter" title="<?php echo e(translate('Twitter')); ?>"><i class="lab la-twitter"></i></a>
			                        </li>
									<?php endif; ?>
									<?php if(get_setting('apple_login_activation') == 1): ?>
			                        <li class="list-inline-item">
			                            <a href="<?php echo e(route('social.login', ['provider' => 'apple'])); ?>" class="apple" title="<?php echo e(translate('Apple')); ?>"><i class="lab la-apple"></i></a>
			                        </li>
									<?php endif; ?>
								</ul>
							</div>
							<?php endif; ?>

							<div class="text-center">
								<p class="text-muted mb-0"><?php echo e(translate("Already have an account?")); ?></p>
								<a href="<?php echo e(route('login')); ?>"><?php echo e(translate('Login to your account')); ?></a>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
	<?php if(get_setting('google_recaptcha_activation') == 1): ?>
		<?php echo $__env->make('partials.recaptcha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endif; ?>
	<?php if(addon_activation('otp_system')): ?>
		<?php echo $__env->make('partials.emailOrPhone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/poly1278/shadi.polytronx.com/resources/views/frontend/user_registration.blade.php ENDPATH**/ ?>