<div class="card-header bg-dark text-white">
    <h5 class="mb-0 h6"><?php echo e(translate('Family Information')); ?></h5>
</div>
<div class="card-body">
    <form action="<?php echo e(route('families.update', $member->id)); ?>" method="POST">
        <input name="_method" type="hidden" value="PATCH">
        <?php echo csrf_field(); ?>
        <div class="form-group row">
            <div class="col-md-6">
                <label for="father"><?php echo e(translate('Father')); ?></label>
                <input type="text" name="father" value="<?php echo e($member->families->father ?? ""); ?>" class="form-control" placeholder="<?php echo e(translate('Father')); ?>" required>
                <?php $__errorArgs = ['father'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="form-text text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6">
                <label for="mother"><?php echo e(translate('Mother')); ?></label>
                <input type="text" name="mother" value="<?php echo e($member->families->mother ?? ""); ?>" placeholder="<?php echo e(translate('Mother')); ?>" class="form-control" required>
                <?php $__errorArgs = ['mother'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="form-text text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="form-group row">
            <div class="col-md-6">
                <label for="sibling"><?php echo e(translate('Sibling')); ?></label>
                <input type="text" name="sibling" value="<?php echo e($member->families->sibling ?? ""); ?>" class="form-control" placeholder="<?php echo e(translate('Sibling')); ?>" required>
                <?php $__errorArgs = ['sibling'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="form-text text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="text-right">
            <button type="submit" class="btn btn-primary btn-sm"><?php echo e(translate('Update')); ?></button>
        </div>
    </form>
</div>
<?php /**PATH /home/poly1278/shadi.polytronx.com/resources/views/admin/members/edit/family_information.blade.php ENDPATH**/ ?>