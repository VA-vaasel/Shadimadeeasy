

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            <h5 class="mb-md-0 h6"><?php echo e(translate('Role Information')); ?></h5>
        </div>

        <!--Horizontal Form-->
        <!--===================================================-->
        <form class="form-horizontal" action="<?php echo e(route('roles.store')); ?>" method="POST" enctype="multipart/form-data">
        	<?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="row">
                    <div class="col-8 mx-auto">
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label"><?php echo e(translate('Role Name')); ?><span class="text-danger">*</span></label>
                            <div class="col-md-9">
                                <input type="text" placeholder="<?php echo e(translate('Name')); ?>" id="name" name="name" class="form-control" required>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card-header bord-btm">
                    <h5 class="mb-md-0 h6"><?php echo e(translate('Permissions')); ?></h5>
                </div>
                <br>

                <?php
                    $permission_groups =  \App\Models\Permission::all()->groupBy('parent');
                ?>
                <?php $__currentLoopData = $permission_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $check = true;
                        if($permission_group[0]['parent'] == 'otp_system' || $permission_group[0]['parent'] == 'support_tickets' || $permission_group[0]['parent'] == 'referral_system')
                        {
                            if (addon_activation($permission_group[0]['parent']) == false) {
                                $check = false;
                            }
                        }
                    ?>
                    <?php if($check): ?>
                        <div class="bd-example">
                            <ul class="list-group">
                                <li class="list-group-item bg-light" aria-current="true">
                                    <?php echo e(translate(Str::headline($permission_group[0]['parent']))); ?>

                                </li>
                                <li class="list-group-item">
                                    <div class="row">
                                        <?php $__currentLoopData = $permission_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-lg-2 col-md-3 col-sm-4 col-xs-6">
                                                <div class="p-2 border mt-1 mb-2">
                                                    <label class="control-label d-flex"><?php echo e(translate(Str::headline($permission->name))); ?></label>
                                                    <label class="aiz-switch aiz-switch-success">
                                                        <input type="checkbox" name="permissions[]" class="form-control demo-sw" value="<?php echo e($permission->id); ?>">
                                                        <span class="slider round"></span>
                                                    </label>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </li>
                          </ul>
                    <?php endif; ?>
                  </div>
                  <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="form-group mb-3 mt-3 text-right">
                    <button type="submit" class="btn btn-primary"><?php echo e(translate('Save')); ?></button>
                </div>
            </div>
        </form>
        <!--===================================================-->
        <!--End Horizontal Form-->

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/poly1278/shadi.polytronx.com/resources/views/admin/staff/roles/create.blade.php ENDPATH**/ ?>