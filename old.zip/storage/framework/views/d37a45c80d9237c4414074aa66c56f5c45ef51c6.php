<div class="modal fade create_edit_modal" id="modal-basic">
	<div class="modal-dialog">
		<div class="modal-content create_edit_modal_content">

    	</div>
	</div>
</div>

<!-- large Modal -->
<div class="modal fade create_update_large_modal" id="modal-lg">
	<div class="modal-dialog modal-dialog-centered modal-lg">
		<div class="modal-content">

		</div>
	</div>
</div>
<?php /**PATH /home/poly1278/shadi.polytronx.com/resources/views/modals/create_edit_modal.blade.php ENDPATH**/ ?>